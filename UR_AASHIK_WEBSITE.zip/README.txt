UR_AASHIK_SITE
--------------
How to use:
- Open login.html in a browser (or upload whole folder to hosting like Netlify)
- Login credentials (case-insensitive): 
    Username: URAASHIK
    Password: URSANU
- After login you'll be redirected to index.html (main downloads page)
- Replace assets/bg.mp4 with your background video file
- Replace assets/voice.mp3 with your background audio (so it will play once on first touch)
- Replace each card link (script.js : url field) with your real download link (mediafire etc)
- You can add more images to assets and increase the number in script.js (loop limit)

Files included:
- login.html
- index.html
- style.css
- script.js
- assets/img1..img10.jpg (placeholder images)
- assets/bg.mp4 (NOT included) -> replace with your video
- assets/voice.mp3 (placeholder empty file) -> replace with actual audio